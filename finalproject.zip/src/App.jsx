import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  return (
    <div className="App">
      <Navbar /> {/* Usa el componente */}
      <main>
        <h1>Bienvenido a mi proyecto</h1>
        {/* Otros componentes o contenido */}
      </main>
    </div>
  );
}


function App() {

  return (
    <Login />
  )
}

export default App;

