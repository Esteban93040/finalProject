import React from 'react';
import NavBar from '../NavBar/NavBar';
import Graficas from '../genrarGraficas/Graficas';
import TablaUsuarios from '../TablaUsuarios/TablaUsuarios';

const Home = () => {
    return (
        <div>
            <NavBar />

        </div>
  )
}

export default Home;